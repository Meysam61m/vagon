@extends('layouts.app')
@section('title', 'جزئیات درخواست بارگیری')

@section('content')
    @php
        $readyToBillCount = $cargo->wagons->filter(fn($w) => !$w->is_settled && $w->isLoaded() && $w->tariff_id)->count();
        $unsettledCount = $cargo->wagons->where('is_settled', false)->count();
        $fullySettledCount = $cargo->fullySettledWagonsCount();
        $totalWagonsCount = $cargo->wagons->count();
        $allWagonsSettled = $cargo->allWagonsFullySettled();
        $cargoPrintUrl = \Illuminate\Support\Facades\Route::has('cargo.print')
            ? route('cargo.print', $cargo)
            : url('/cargo/'.$cargo->id.'/print');
        $firstSuggestedTariffId = collect($suggestedTariffs ?? [])->filter()->first()
            ?: $cargo->wagons->whereNotNull('tariff_id')->first()?->tariff_id;
        $repOwners = ($cargo->representative?->owners ?? collect())->where('is_active', true)->sortBy('name')->values();
    @endphp

    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h4 class="mb-0">درخواست بارگیری: {{ $cargo->request_number }}</h4>
            <span class="badge bg-secondary fs-6">{{ $cargo->statusLabel() }}</span>
            @if($allWagonsSettled)
                <span class="badge bg-success fs-6">تسویه کامل همه واگن‌ها ({{ $totalWagonsCount }} واگن)</span>
            @else
                <span class="badge bg-warning text-dark">تسویه واگن‌های درخواست: {{ $fullySettledCount }} از {{ $totalWagonsCount }}</span>
            @endif
        </div>

        <div class="d-flex gap-2 flex-wrap align-items-center">
            @if($allWagonsSettled)
                <a href="{{ $cargoPrintUrl }}" target="_blank" rel="noopener" class="btn btn-primary btn-sm fw-semibold">
                    چاپ برگه ۴ بخشی درخواست {{ $cargo->request_number }}
                </a>
            @endif
            @if($readyToBillCount > 0)
                @if($cargo->owner_id)
                    <form method="POST" action="{{ route('cargo.quick-bill', $cargo) }}" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-success btn-sm fw-semibold">
                            صدور صورتحساب جهت ثبت فیش و تسویه ({{ $readyToBillCount }} واگن)
                        </button>
                    </form>
                @else
                    <div class="d-inline-flex flex-column align-items-start gap-1">
                        <form method="POST" action="{{ route('cargo.quick-bill', $cargo) }}" class="d-inline-flex gap-1 align-items-center bg-warning-subtle border border-warning rounded p-1">
                            @csrf
                            <select name="owner_id" class="form-select form-select-sm" style="min-width: 230px;" required>
                                <option value="">صاحب کالا (مرتبط با {{ $cargo->representative?->name }})…</option>
                                @foreach($repOwners as $owner)
                                    <option value="{{ $owner->id }}" @selected((int) session('selected_owner_id') === (int) $owner->id || $repOwners->count() === 1)>{{ $owner->name }}</option>
                                @endforeach
                            </select>
                            <button type="submit" class="btn btn-success btn-sm fw-semibold text-nowrap">
                                تعیین صاحب کالا و صدور صورتحساب
                            </button>
                        </form>
                        <button type="button"
                                class="btn btn-sm btn-outline-primary py-0 px-2"
                                style="font-size: 0.78rem;"
                                data-bs-toggle="modal"
                                data-bs-target="#cargoShowQuickOwnerModal">
                            + تعریف صاحب کالای جدید (مرتبط با {{ $cargo->representative?->name }})
                        </button>
                    </div>
                @endif
            @endif
            <a href="{{ route('cargo.create') }}" class="btn btn-outline-primary btn-sm">+ درخواست جدید</a>
            <a href="{{ route('cargo.index') }}" class="btn btn-outline-secondary btn-sm">لیست درخواست‌ها</a>
        </div>
    </div>

    <div class="card p-4 mb-4">
        <div class="row g-3">
            <div class="col-md-3">
                <strong>صاحب کالا:</strong>
                @if($cargo->owner)
                    {{ $cargo->owner->name }}
                @else
                    <span class="badge bg-warning text-dark">ناشناس (تعیین هنگام صدور صورتحساب)</span>
                @endif
            </div>
            <div class="col-md-3"><strong>نماینده:</strong> {{ $cargo->representative?->name ?? '—' }}</div>
            <div class="col-md-3"><strong>تاریخ درخواست:</strong> {{ $cargo->request_date_shamsi }}</div>
            <div class="col-md-3"><strong>اپراتور ثبت‌کننده:</strong> {{ $cargo->operator?->name ?? '—' }}</div>
        </div>
        @if($cargo->notes)
            <div class="mt-3"><strong>توضیحات:</strong> {{ $cargo->notes }}</div>
        @endif
    </div>

    {{-- فرم افزودن واگن جدید به همین درخواست بارگیری --}}
    @php
        $lastCargoDescription = $cargo->wagons->last()?->cargo_description ?? '';
        $lastLineNumber = $cargo->wagons->last()?->line_number ?? '';
        $oldNewWagons = old('new_wagons', [['number' => '', 'description' => $lastCargoDescription, 'line_number' => $lastLineNumber]]);
    @endphp
    <div class="card p-3 mb-4 border-primary">
        <form method="POST"
              action="{{ \Illuminate\Support\Facades\Route::has('cargo.wagons.store') ? route('cargo.wagons.store', $cargo) : url('/cargo/'.$cargo->id.'/wagons') }}"
              id="add-wagon-to-cargo-form">
            @csrf
            <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                <h6 class="mb-0 text-primary">
                    + افزودن واگن جدید به این درخواست بارگیری
                </h6>
                <button type="button" id="add-more-new-wagon-row" class="btn btn-sm btn-outline-primary">
                    + ردیف واگن دیگر
                </button>
            </div>
            <div id="new-wagon-rows-container">
                @foreach($oldNewWagons as $nwIdx => $nw)
                    <div class="row g-2 align-items-start mb-2 new-wagon-row">
                        <div class="col-md-3">
                            <input type="text"
                                   name="new_wagons[{{ $nwIdx }}][number]"
                                   value="{{ $nw['number'] ?? '' }}"
                                   class="form-control form-control-sm font-monospace @error('new_wagons.'.$nwIdx.'.number') is-invalid @enderror"
                                   data-new-wagon-number
                                   placeholder="شماره واگن جدید (مثلاً 663532)"
                                   required>
                            @error('new_wagons.'.$nwIdx.'.number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-4">
                            <input type="text"
                                   name="new_wagons[{{ $nwIdx }}][description]"
                                   value="{{ $nw['description'] ?? $lastCargoDescription }}"
                                   class="form-control form-control-sm @error('new_wagons.'.$nwIdx.'.description') is-invalid @enderror"
                                   data-new-wagon-description
                                   placeholder="شرح کالا (اجباری — پیشنهاد خودکار از واگن قبلی)"
                                   required>
                            @error('new_wagons.'.$nwIdx.'.description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-2">
                            <input type="text"
                                   name="new_wagons[{{ $nwIdx }}][line_number]"
                                   value="{{ $nw['line_number'] ?? $lastLineNumber }}"
                                   class="form-control form-control-sm @error('new_wagons.'.$nwIdx.'.line_number') is-invalid @enderror"
                                   data-new-wagon-line
                                   placeholder="شماره خط (مثلاً خط ۲)">
                            @error('new_wagons.'.$nwIdx.'.line_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3 d-flex gap-1">
                            @if($loop->first)
                                <button type="submit" class="btn btn-sm btn-primary flex-grow-1 fw-semibold">
                                    + ثبت و افزودن واگن
                                </button>
                            @else
                                <button type="button" class="btn btn-sm btn-outline-danger w-100 remove-new-wagon-row">
                                    حذف ردیف
                                </button>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </form>
    </div>

    @if($cargo->status !== 'billed')
        <form method="POST" action="{{ route('cargo.load', $cargo) }}" class="card p-4 mb-4" id="cargo-loading-form">
            @csrf
            <div class="row g-3 align-items-end mb-3">
                <div class="col-md-5">
                    <h6 class="mb-1">ثبت عملیات بارگیری ({{ $cargo->wagons->count() }} واگن)</h6>
                    <div class="text-muted small">
                        ثبت بارگیری با صاحب کالای «ناشناس» مجاز است؛ اما <strong>هنگام صدور صورتحساب</strong> انتخاب نام صاحب کالای مرتبط با نماینده الزامی است.
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label mb-1" for="loading_owner_id">
                        صاحب کالا (مرتبط با نماینده «{{ $cargo->representative?->name }}»)
                        @if(!$cargo->owner_id)
                            <span class="badge bg-warning text-dark small">فعلاً ناشناس — اجباری برای فاکتور</span>
                        @endif
                    </label>
                    <select name="owner_id" id="loading_owner_id" class="form-select @error('owner_id') is-invalid @enderror">
                        <option value="">— ناشناس / نامشخص (فقط ذخیره بارگیری) —</option>
                        @foreach($repOwners as $owner)
                            <option value="{{ $owner->id }}" @selected((int) old('owner_id', session('selected_owner_id', $cargo->owner_id)) === (int) $owner->id)>
                                {{ $owner->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('owner_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    <div class="mt-1 d-flex justify-content-between align-items-center flex-wrap gap-1">
                        @if($repOwners->isEmpty())
                            <span class="text-danger small">
                                به نماینده «{{ $cargo->representative?->name }}» هنوز صاحب کالایی تخصیص داده نشده است.
                            </span>
                        @endif
                        <button type="button"
                                class="btn btn-sm btn-outline-primary py-0 px-2"
                                style="font-size: 0.78rem;"
                                data-bs-toggle="modal"
                                data-bs-target="#cargoShowQuickOwnerModal">
                            + تعریف صاحب کالای جدید
                        </button>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label mb-1" for="loading_date_shamsi">تاریخ بارگیری (شمسی)</label>
                    <input type="text" name="loading_date_shamsi" id="loading_date_shamsi"
                           value="{{ old('loading_date_shamsi', $loadingDateShamsi) }}"
                           class="form-control jalali-datepicker" autocomplete="off" required>
                </div>
            </div>

            @if($unsettledCount > 0)
                {{-- نوار ابزار اعمال یکجای تعرفه و وزن کامل قرارداد برای حذف کار تکراری اپراتور --}}
                <div class="card bg-light border-primary p-3 mb-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label small fw-bold mb-1" for="bulk_tariff_select">
                                تعرفه یکجا برای همه واگن‌های این درخواست
                            </label>
                            <select id="bulk_tariff_select" class="form-select form-select-sm">
                                <option value="">انتخاب تعرفه برای اعمال گروهی…</option>
                                @foreach($tariffs as $tariff)
                                    @if($tariff->is_active)
                                        <option value="{{ $tariff->id }}"
                                                data-capacity="{{ $tariff->capacity }}"
                                                data-rate="{{ $tariff->rate }}"
                                                @selected((int) $firstSuggestedTariffId === (int) $tariff->id)>
                                            {{ $tariff->title }} — ظرفیت: {{ $tariff->capacity }} تن ({{ number_format($tariff->rate) }} ریال)
                                        </option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold mb-1" for="bulk_weight_input">
                                وزن هر واگن (تن — طبق قرارداد)
                            </label>
                            <input type="number" step="0.01" min="0.01" max="200" id="bulk_weight_input"
                                   class="form-control form-control-sm"
                                   placeholder="مثلاً 65">
                        </div>
                        <div class="col-md-4 d-flex gap-2">
                            <button type="button" id="apply-bulk-loading-btn" class="btn btn-sm btn-primary flex-grow-1">
                                اعمال تعرفه و وزن به همه واگن‌ها
                            </button>
                            <button type="button" id="fill-all-capacity-btn" class="btn btn-sm btn-outline-dark" title="پر کردن وزن همه واگن‌ها بر اساس ظرفیت تعرفه انتخابی هر ردیف">
                                تکمیل ظرفیت همه
                            </button>
                        </div>
                    </div>
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-bordered bg-white align-middle">
                    <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>شماره واگن</th>
                        <th style="min-width: 170px;">شرح کالا <span class="text-danger">*</span></th>
                        <th style="min-width: 110px;">شماره خط</th>
                        <th>صاحب کالا</th>
                        <th style="min-width: 260px;">تعرفه</th>
                        <th style="min-width: 155px;">وزن بارگیری (تن)</th>
                        <th>وضعیت</th>
                        <th>صورتحساب</th>
                        <th>عملیات واگن</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($cargo->wagons as $wagon)
                        @php
                            $suggestedId = $suggestedTariffs[$wagon->id] ?? null;
                            $oldTariff = old('loading.'.$wagon->id.'.tariff_id', $wagon->tariff_id ?? $suggestedId);
                            $selectedTariffObj = $tariffs->firstWhere('id', (int) $oldTariff);
                            $defaultWeight = $wagon->loaded_weight ?? ($selectedTariffObj ? $selectedTariffObj->capacity : null);
                            $oldWeight = old('loading.'.$wagon->id.'.weight', $defaultWeight);
                            $isAutoSuggested = !$wagon->tariff_id && $suggestedId && (int) $oldTariff === (int) $suggestedId;
                        @endphp
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>
                                <div class="fw-bold font-monospace">{{ $wagon->wagon_number }}</div>
                                @if($wagon->isNumberEdited())
                                    <span class="badge bg-info text-dark mt-1">شماره اصلاح‌شده</span>
                                    <div class="small text-muted">قبلی: <span class="text-decoration-line-through">{{ $wagon->previous_wagon_number }}</span></div>
                                    <div class="small text-muted">علت: {{ $wagon->owner_change_note }}</div>
                                @endif
                            </td>
                            <td>
                                @if($wagon->is_settled)
                                    {{ $wagon->cargo_description ?: '—' }}
                                @else
                                    <input type="text"
                                           name="loading[{{ $wagon->id }}][description]"
                                           value="{{ old('loading.'.$wagon->id.'.description', $wagon->cargo_description) }}"
                                           class="form-control form-control-sm @error('loading.'.$wagon->id.'.description') is-invalid @enderror"
                                           data-loading-description
                                           placeholder="مثلاً میلگرد، کاشی">
                                    @error('loading.'.$wagon->id.'.description')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                @endif
                            </td>
                            <td>
                                @if($wagon->is_settled)
                                    {{ $wagon->line_number ?: '—' }}
                                @else
                                    <input type="text"
                                           name="loading[{{ $wagon->id }}][line_number]"
                                           value="{{ old('loading.'.$wagon->id.'.line_number', $wagon->line_number) }}"
                                           class="form-control form-control-sm @error('loading.'.$wagon->id.'.line_number') is-invalid @enderror"
                                           placeholder="مثلاً خط ۲">
                                    @error('loading.'.$wagon->id.'.line_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                @endif
                            </td>
                            <td>
                                <div>{{ $wagon->ownerName() }}</div>
                                @if($wagon->isOwnerChanged())
                                    <span class="badge bg-warning text-dark mt-1">ویرایش‌شده</span>
                                    <div class="small text-muted">قبلی: {{ $wagon->previousOwner?->name ?? '—' }}</div>
                                    <div class="small text-muted">علت: {{ $wagon->owner_change_note }}</div>
                                @endif
                            </td>
                            <td>
                                @if($wagon->is_settled)
                                    {{ $wagon->tariff?->title ?? '—' }}
                                @else
                                    <select name="loading[{{ $wagon->id }}][tariff_id]"
                                            class="form-select form-select-sm wagon-tariff-select"
                                            data-wagon-id="{{ $wagon->id }}">
                                        <option value="">انتخاب تعرفه…</option>
                                        @foreach($tariffs as $tariff)
                                            <option value="{{ $tariff->id }}"
                                                    data-capacity="{{ $tariff->capacity }}"
                                                    @selected((string) $oldTariff === (string) $tariff->id)>
                                                {{ $tariff->title }}{{ $tariff->is_active ? '' : ' (غیرفعال)' }}
                                                — {{ $tariff->capacity }} تن
                                            </option>
                                        @endforeach
                                    </select>
                                    @if($isAutoSuggested)
                                        <div class="small text-primary mt-1" data-suggested-hint>
                                            ✓ پیشنهاد خودکار از روی شرح کالا
                                        </div>
                                    @endif
                                @endif
                            </td>
                            <td>
                                @if($wagon->is_settled)
                                    {{ $wagon->loaded_weight }}
                                @else
                                    <div class="input-group input-group-sm">
                                        <input type="number" step="0.01" min="0.01"
                                               max="{{ $selectedTariffObj ? $selectedTariffObj->capacity : 200 }}"
                                               name="loading[{{ $wagon->id }}][weight]"
                                               value="{{ $oldWeight }}"
                                               class="form-control wagon-weight-input @error('loading.'.$wagon->id.'.weight') is-invalid @enderror"
                                               placeholder="مثلاً {{ $selectedTariffObj ? $selectedTariffObj->capacity : 65 }}">
                                        <button type="button" class="btn btn-outline-secondary fill-row-capacity-btn" title="قرار دادن ظرفیت کامل تعرفه">
                                            کامل
                                        </button>
                                    </div>
                                    <div class="small text-danger mt-1 d-none" data-capacity-warning></div>
                                    @error('loading.'.$wagon->id.'.weight')
                                        <div class="invalid-feedback d-block">{{ $message }}</div>
                                    @enderror
                                @endif
                            </td>
                            <td>
                                @if($wagon->is_settled)
                                    <span class="badge bg-success">تسویه شده</span>
                                @elseif($wagon->isLoaded())
                                    <span class="badge bg-info text-dark">بارگیری شده</span>
                                @else
                                    <span class="badge bg-warning text-dark">در انتظار بارگیری</span>
                                @endif
                            </td>
                            <td>
                                @if($wagon->billingItem?->billing)
                                    <a href="{{ route('billing.show', $wagon->billingItem->billing) }}">
                                        {{ $wagon->billingItem->billing->billing_number }}
                                    </a>
                                @else
                                    —
                                @endif
                            </td>
                            <td class="text-nowrap">
                                <div class="d-inline-flex gap-1 align-items-center">
                                    <a href="{{ \Illuminate\Support\Facades\Route::has('wagons.edit-owner') ? route('wagons.edit-owner', $wagon) : url('/wagons/'.$wagon->id.'/edit-owner') }}" class="btn btn-sm btn-outline-primary">
                                        ویرایش
                                    </a>
                                    @if(! $wagon->is_settled)
                                        <button type="submit"
                                                form="delete-wagon-form-{{ $wagon->id }}"
                                                class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('آیا از حذف واگن «{{ $wagon->wagon_number }}» از این درخواست بارگیری مطمئن هستید؟');">
                                            حذف واگن
                                        </button>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <div class="d-flex gap-2 flex-wrap align-items-center">
                <button class="btn btn-success fw-semibold" type="submit" name="issue_billing" value="1">
                    ذخیره بارگیری و صدور صورتحساب (جهت ثبت فیش و تسویه)
                </button>
                <button class="btn btn-primary" type="submit" name="issue_billing" value="0">
                    فقط ذخیره بارگیری
                </button>
            </div>
        </form>

        {{-- فرم‌های مجزای حذف واگن (خارج از فرم اصلی برای رعایت استاندارد HTML) --}}
        @foreach($cargo->wagons as $wagon)
            @if(! $wagon->is_settled)
                <form id="delete-wagon-form-{{ $wagon->id }}"
                      method="POST"
                      action="{{ \Illuminate\Support\Facades\Route::has('wagons.delete') ? route('wagons.delete', $wagon) : url('/wagons/'.$wagon->id.'/delete') }}"
                      class="d-none">
                    @csrf
                </form>
            @endif
        @endforeach
    @else
        <div class="card p-4 mb-4">
            <h6 class="mb-3">واگن‌های این درخواست (صورتحساب‌شده)</h6>
            <div class="table-responsive">
                <table class="table table-bordered bg-white align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>شماره واگن</th>
                        <th>شرح کالا</th>
                        <th>شماره خط</th>
                        <th>صاحب کالا</th>
                        <th>تعرفه</th>
                        <th>وزن (تن)</th>
                        <th>وضعیت</th>
                        <th>صورتحساب</th>
                        <th>ویرایش واگن</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($cargo->wagons as $wagon)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>
                                <div class="fw-bold font-monospace">{{ $wagon->wagon_number }}</div>
                                @if($wagon->isNumberEdited())
                                    <span class="badge bg-info text-dark mt-1">شماره اصلاح‌شده</span>
                                    <div class="small text-muted">قبلی: <span class="text-decoration-line-through">{{ $wagon->previous_wagon_number }}</span></div>
                                    <div class="small text-muted">علت: {{ $wagon->owner_change_note }}</div>
                                @endif
                            </td>
                            <td>{{ $wagon->cargo_description ?: '—' }}</td>
                            <td>{{ $wagon->line_number ?: '—' }}</td>
                            <td>
                                <div>{{ $wagon->ownerName() }}</div>
                                @if($wagon->isOwnerChanged())
                                    <span class="badge bg-warning text-dark mt-1">ویرایش‌شده</span>
                                    <div class="small text-muted">قبلی: {{ $wagon->previousOwner?->name ?? '—' }}</div>
                                    <div class="small text-muted">علت: {{ $wagon->owner_change_note }}</div>
                                @endif
                            </td>
                            <td>{{ $wagon->tariff?->title ?? '—' }}</td>
                            <td>{{ $wagon->loaded_weight ?? '—' }}</td>
                            <td><span class="badge bg-success">تسویه شده</span></td>
                            <td>
                                @if($wagon->billingItem?->billing)
                                    <a href="{{ route('billing.show', $wagon->billingItem->billing) }}" class="fw-bold">
                                        {{ $wagon->billingItem->billing->billing_number }}
                                    </a>
                                @else
                                    —
                                @endif
                            </td>
                            <td class="text-nowrap">
                                <a href="{{ \Illuminate\Support\Facades\Route::has('wagons.edit-owner') ? route('wagons.edit-owner', $wagon) : url('/wagons/'.$wagon->id.'/edit-owner') }}" class="btn btn-sm btn-outline-primary">
                                    ویرایش واگن
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif

    <a href="{{ route('cargo.index') }}" class="btn btn-secondary">بازگشت</a>

    {{-- مودال تعریف صاحب کالای جدید برای این درخواست بارگیری --}}
    @php $showModalReps = $representatives ?? collect(); @endphp
    <div class="modal fade" id="cargoShowQuickOwnerModal" tabindex="-1" aria-labelledby="cargoShowQuickOwnerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form method="POST" action="{{ route('owners.store') }}" class="modal-content">
                @csrf
                <input type="hidden" name="redirect_to" value="cargo.show">
                <input type="hidden" name="cargo_request_id" value="{{ $cargo->id }}">
                <input type="hidden" name="assign_to_cargo_request" value="1">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="cargoShowQuickOwnerModalLabel">
                        تعریف صاحب کالای جدید (درخواست {{ $cargo->request_number }})
                    </h5>
                    <button type="button" class="btn-close ms-0 me-auto" data-bs-dismiss="modal" aria-label="بستن"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info py-2 small mb-3">
                        صاحب کالای جدید پس از ثبت، به نماینده <strong>«{{ $cargo->representative?->name ?? '—' }}»</strong> متصل شده و به‌صورت خودکار روی این درخواست بارگیری قرار می‌گیرد.
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label" for="show_quick_owner_name">نام صاحب کالا <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="show_quick_owner_name" class="form-control" required placeholder="نام شخص حقیقی یا شرکت">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="show_quick_owner_national_id">کد ملی / شناسه ملی</label>
                            <input type="text" name="national_id" id="show_quick_owner_national_id" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="show_quick_owner_phone">تلفن</label>
                            <input type="text" name="phone" id="show_quick_owner_phone" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="show_quick_owner_economic_code">کد اقتصادی</label>
                            <input type="text" name="economic_code" id="show_quick_owner_economic_code" class="form-control">
                        </div>
                        <div class="col-md-8">
                            <label class="form-label" for="show_quick_owner_address">آدرس</label>
                            <input type="text" name="address" id="show_quick_owner_address" class="form-control">
                        </div>
                        @if($showModalReps->isNotEmpty())
                            <div class="col-12">
                                <label class="form-label mb-1">نماینده مرتبط با این صاحب کالا</label>
                                <div class="row g-2 border rounded p-2 bg-light" style="max-height: 170px; overflow-y: auto;">
                                    @foreach($showModalReps as $rep)
                                        <div class="col-md-4">
                                            <div class="form-check">
                                                <input type="checkbox"
                                                       class="form-check-input"
                                                       name="representative_ids[]"
                                                       value="{{ $rep->id }}"
                                                       id="show_rep_{{ $rep->id }}"
                                                       @checked((int) $cargo->representative_id === (int) $rep->id)>
                                                <label class="form-check-label small" for="show_rep_{{ $rep->id }}">{{ $rep->name }}</label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        @elseif($cargo->representative_id)
                            <input type="hidden" name="representative_ids[]" value="{{ $cargo->representative_id }}">
                        @endif
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <a href="{{ route('owners.create', ['redirect_to' => 'cargo.show', 'cargo_request_id' => $cargo->id, 'representative_id' => $cargo->representative_id]) }}"
                       class="btn btn-link btn-sm text-decoration-none">
                        باز کردن فرم کامل تعریف صاحب کالا
                    </a>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                        <button type="submit" class="btn btn-primary fw-semibold">ذخیره و انتخاب صاحب کالا</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const bulkTariffSelect = document.getElementById('bulk_tariff_select');
            const bulkWeightInput = document.getElementById('bulk_weight_input');
            const applyBulkBtn = document.getElementById('apply-bulk-loading-btn');
            const fillAllCapacityBtn = document.getElementById('fill-all-capacity-btn');

            function getRowCapacity(row) {
                if (!row) return null;
                const select = row.querySelector('.wagon-tariff-select');
                if (!select) return null;
                const opt = select.options[select.selectedIndex];
                if (!opt || !opt.dataset.capacity) return null;
                const cap = parseFloat(opt.dataset.capacity);
                return (!isNaN(cap) && cap > 0) ? cap : null;
            }

            function syncAndClampRowWeight(row) {
                if (!row) return;
                const weightInput = row.querySelector('.wagon-weight-input');
                const warnEl = row.querySelector('[data-capacity-warning]');
                if (!weightInput) return;

                const cap = getRowCapacity(row);
                if (cap !== null) {
                    weightInput.max = String(cap);
                    weightInput.placeholder = 'حداکثر ' + cap;
                    const val = parseFloat(weightInput.value);
                    if (!isNaN(val) && val > cap) {
                        weightInput.value = String(cap);
                        if (warnEl) {
                            warnEl.textContent = 'حداکثر تناژ مجاز این تعرفه ' + cap + ' تن است.';
                            warnEl.classList.remove('d-none');
                        }
                    } else if (warnEl) {
                        warnEl.classList.add('d-none');
                        warnEl.textContent = '';
                    }
                } else {
                    weightInput.max = '200';
                    if (warnEl) {
                        warnEl.classList.add('d-none');
                        warnEl.textContent = '';
                    }
                }
            }

            function syncBulkCapacityFromSelect() {
                if (!bulkTariffSelect || !bulkWeightInput) return;
                const opt = bulkTariffSelect.options[bulkTariffSelect.selectedIndex];
                if (opt && opt.dataset.capacity) {
                    bulkWeightInput.max = opt.dataset.capacity;
                    bulkWeightInput.value = opt.dataset.capacity;
                } else {
                    bulkWeightInput.max = '200';
                }
            }

            if (bulkTariffSelect) {
                bulkTariffSelect.addEventListener('change', syncBulkCapacityFromSelect);
                syncBulkCapacityFromSelect();
            }

            if (bulkWeightInput) {
                bulkWeightInput.addEventListener('input', function () {
                    if (!bulkTariffSelect) return;
                    const opt = bulkTariffSelect.options[bulkTariffSelect.selectedIndex];
                    const cap = (opt && opt.dataset.capacity) ? parseFloat(opt.dataset.capacity) : null;
                    const val = parseFloat(bulkWeightInput.value);
                    if (cap !== null && !isNaN(cap) && !isNaN(val) && val > cap) {
                        bulkWeightInput.value = String(cap);
                    }
                });
            }

            // اعمال یکجای تعرفه و وزن به تمام واگن‌های تسویه‌نشده
            if (applyBulkBtn) {
                applyBulkBtn.addEventListener('click', function () {
                    const tariffId = bulkTariffSelect ? bulkTariffSelect.value : '';
                    const weightVal = bulkWeightInput ? bulkWeightInput.value : '';

                    document.querySelectorAll('.wagon-tariff-select').forEach(function (select) {
                        if (tariffId) {
                            select.value = tariffId;
                        }
                        const row = select.closest('tr');
                        const weightInput = row ? row.querySelector('.wagon-weight-input') : null;
                        if (weightInput) {
                            const opt = select.options[select.selectedIndex];
                            const cap = (opt && opt.dataset.capacity) ? parseFloat(opt.dataset.capacity) : null;
                            if (weightVal) {
                                const parsedW = parseFloat(weightVal);
                                weightInput.value = (cap !== null && !isNaN(parsedW) && parsedW > cap)
                                    ? String(cap)
                                    : weightVal;
                            } else if (cap !== null) {
                                weightInput.value = String(cap);
                            }
                            syncAndClampRowWeight(row);
                            weightInput.dispatchEvent(new Event('input', { bubbles: true }));
                        }
                    });
                });
            }

            // تکمیل ظرفیت کامل قرارداد برای تمام ردیف‌ها بر اساس تعرفه هر ردیف
            if (fillAllCapacityBtn) {
                fillAllCapacityBtn.addEventListener('click', function () {
                    document.querySelectorAll('.wagon-tariff-select').forEach(function (select) {
                        const opt = select.options[select.selectedIndex];
                        const row = select.closest('tr');
                        const weightInput = row ? row.querySelector('.wagon-weight-input') : null;
                        if (weightInput && opt && opt.dataset.capacity) {
                            weightInput.value = opt.dataset.capacity;
                            syncAndClampRowWeight(row);
                            weightInput.dispatchEvent(new Event('input', { bubbles: true }));
                        }
                    });
                });
            }

            // با تغییر تعرفه هر ردیف، ظرفیت کامل آن تعرفه در وزن همان ردیف (و ردیف‌های خالی بعدی) قرار می‌گیرد
            document.querySelectorAll('.wagon-tariff-select').forEach(function (select) {
                const currentRow = select.closest('tr');
                syncAndClampRowWeight(currentRow);

                select.addEventListener('change', function () {
                    const opt = select.options[select.selectedIndex];
                    const row = select.closest('tr');
                    const weightInput = row ? row.querySelector('.wagon-weight-input') : null;

                    if (weightInput && opt && opt.dataset.capacity) {
                        weightInput.value = opt.dataset.capacity;
                        syncAndClampRowWeight(row);
                        weightInput.dispatchEvent(new Event('input', { bubbles: true }));
                    } else {
                        syncAndClampRowWeight(row);
                    }

                    // انتشار خودکار تعرفه به ردیف‌های بعدی که هنوز تعرفه ندارند
                    let nextRow = row ? row.nextElementSibling : null;
                    while (nextRow) {
                        const nextSelect = nextRow.querySelector('.wagon-tariff-select');
                        const nextWeight = nextRow.querySelector('.wagon-weight-input');
                        if (nextSelect && !nextSelect.value && select.value) {
                            nextSelect.value = select.value;
                            if (nextWeight && (!nextWeight.value || nextWeight.value.trim() === '') && opt && opt.dataset.capacity) {
                                nextWeight.value = opt.dataset.capacity;
                                syncAndClampRowWeight(nextRow);
                                nextWeight.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        }
                        nextRow = nextRow.nextElementSibling;
                    }
                });
            });

            // جلوگیری لحظه‌ای از ورود تناژ بیشتر از ظرفیت تعرفه در هر ردیف
            document.querySelectorAll('.wagon-weight-input').forEach(function (weightInput) {
                const row = weightInput.closest('tr');
                weightInput.addEventListener('input', function () {
                    syncAndClampRowWeight(row);
                });
                weightInput.addEventListener('change', function () {
                    syncAndClampRowWeight(row);
                });
            });

            // دکمه «کامل» کنار وزن هر ردیف
            document.querySelectorAll('.fill-row-capacity-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    const row = btn.closest('tr');
                    const select = row ? row.querySelector('.wagon-tariff-select') : null;
                    const weightInput = row ? row.querySelector('.wagon-weight-input') : null;
                    if (!weightInput) return;

                    const opt = select ? select.options[select.selectedIndex] : null;
                    weightInput.value = (opt && opt.dataset.capacity) ? opt.dataset.capacity : '65';
                    weightInput.dispatchEvent(new Event('input', { bubbles: true }));
                });
            });

            // شرح کالا فقط برای واگنی که وزن دارد اجباری می‌شود
            document.querySelectorAll('input[data-loading-description]').forEach(function (input) {
                const row = input.closest('tr');
                const weight = row ? row.querySelector('input[name^="loading["][name$="[weight]"]') : null;

                if (! weight) {
                    return;
                }

                function refresh() {
                    const mustFill = weight.value.trim() !== '' && input.value.trim() === '';

                    input.required = mustFill;
                    input.setCustomValidity(mustFill ? 'شرح کالا برای این واگن الزامی است.' : '');
                }

                weight.addEventListener('input', refresh);
                input.addEventListener('input', refresh);
                refresh();
            });

            // با نوشتن شرح یک واگن، ردیف‌های بعدیِ خالی همان شرح را پیشنهاد می‌گیرند
            document.querySelectorAll('input[data-loading-description]').forEach(function (input) {
                input.addEventListener('input', function () {
                    let nextRow = input.closest('tr') ? input.closest('tr').nextElementSibling : null;

                    while (nextRow) {
                        const nextInput = nextRow.querySelector('input[data-loading-description]');

                        if (! nextInput) {
                            break;
                        }

                        if (nextInput.value.trim() === '') {
                            nextInput.value = input.value;
                            nextInput.dispatchEvent(new Event('input', { bubbles: true }));
                        } else {
                            break;
                        }

                        nextRow = nextRow.nextElementSibling;
                    }
                });
            });
            const loadingOwnerSelect = document.getElementById('loading_owner_id');
            document.querySelectorAll('#cargo-loading-form button[name="issue_billing"]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    const val = btn.value;
                    if ((val === '1' || val === 'print') && loadingOwnerSelect && !loadingOwnerSelect.value) {
                        e.preventDefault();
                        loadingOwnerSelect.focus();
                        alert('هنگام صدور صورتحساب، انتخاب نام صاحب کالا الزامی است.\n\nلطفاً از کادر «صاحب کالا» در بالای جدول، نام صاحب کالا را انتخاب کنید (یا اگر هنوز صاحب کالا مشخص نیست، دکمه «فقط ذخیره بارگیری» را بزنید).');
                    }
                });
            });

            // افزودن ردیف جدید در فرم «افزودن واگن به این درخواست بارگیری» با پیشنهاد خودکار شرح کالا از ردیف قبلی
            const addMoreNewWagonBtn = document.getElementById('add-more-new-wagon-row');
            const newWagonRowsContainer = document.getElementById('new-wagon-rows-container');
            let newWagonRowIndex = newWagonRowsContainer ? newWagonRowsContainer.querySelectorAll('.new-wagon-row').length : 1;

            if (addMoreNewWagonBtn && newWagonRowsContainer) {
                addMoreNewWagonBtn.addEventListener('click', function () {
                    const rows = newWagonRowsContainer.querySelectorAll('.new-wagon-row');
                    const lastRow = rows[rows.length - 1];
                    const lastDescInput = lastRow ? lastRow.querySelector('input[data-new-wagon-description]') : null;
                    const lastLineInput = lastRow ? lastRow.querySelector('input[data-new-wagon-line]') : null;
                    const suggestedDesc = lastDescInput ? lastDescInput.value : '';
                    const suggestedLine = lastLineInput ? lastLineInput.value : '';

                    const idx = newWagonRowIndex++;
                    const rowDiv = document.createElement('div');
                    rowDiv.className = 'row g-2 align-items-start mb-2 new-wagon-row';
                    rowDiv.innerHTML = `
                        <div class="col-md-3">
                            <input type="text"
                                   name="new_wagons[${idx}][number]"
                                   class="form-control form-control-sm font-monospace"
                                   data-new-wagon-number
                                   placeholder="شماره واگن جدید (مثلاً 663532)"
                                   required>
                        </div>
                        <div class="col-md-4">
                            <input type="text"
                                   name="new_wagons[${idx}][description]"
                                   class="form-control form-control-sm"
                                   data-new-wagon-description
                                   placeholder="شرح کالا (اجباری — پیشنهاد خودکار از واگن قبلی)"
                                   required>
                        </div>
                        <div class="col-md-2">
                            <input type="text"
                                   name="new_wagons[${idx}][line_number]"
                                   class="form-control form-control-sm"
                                   data-new-wagon-line
                                   placeholder="شماره خط (مثلاً خط ۲)">
                        </div>
                        <div class="col-md-3 d-flex gap-1">
                            <button type="button" class="btn btn-sm btn-outline-danger w-100 remove-new-wagon-row">
                                حذف ردیف
                            </button>
                        </div>
                    `;

                    const descInput = rowDiv.querySelector('input[data-new-wagon-description]');
                    if (descInput) {
                        descInput.value = suggestedDesc;
                    }
                    const lineInput = rowDiv.querySelector('input[data-new-wagon-line]');
                    if (lineInput) {
                        lineInput.value = suggestedLine;
                    }

                    newWagonRowsContainer.appendChild(rowDiv);

                    const numInput = rowDiv.querySelector('input[data-new-wagon-number]');
                    if (numInput) {
                        numInput.focus();
                    }
                });

                newWagonRowsContainer.addEventListener('click', function (e) {
                    const removeBtn = e.target.closest('.remove-new-wagon-row');
                    if (removeBtn) {
                        const row = removeBtn.closest('.new-wagon-row');
                        if (row && newWagonRowsContainer.querySelectorAll('.new-wagon-row').length > 1) {
                            row.remove();
                        }
                    }
                });
            }
        });
    </script>
@endpush
