<?php

namespace App\Http\Controllers;

use App\Models\Billing;
use App\Models\CargoRequest;
use App\Models\Owner;
use App\Models\Representative;
use App\Models\Wagon;
use App\Models\WagonOwnerLog;
use App\Support\ExcelExport;
use App\Support\JalaliDate;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Morilog\Jalali\Jalalian;

class DashboardController extends Controller
{
    /** حداکثر تعداد ستون نمودار برای بازه‌های طولانی */
    private const MAX_CHART_DAYS = 31;

    public function index(Request $request)
    {
        if (! Gate::allows('view-dashboard')) {
            return redirect()->route('cargo.index');
        }

        [$from, $to] = $this->resolveDateRange($request);

        $billingAggregates = Billing::query()
            ->whereBetween('billing_date', [$from, $to])
            ->where('status', Billing::STATUS_ISSUED)
            ->selectRaw('COUNT(*) as total_billings, COALESCE(SUM(total_amount), 0) as total_amount')
            ->first();

        $pendingWagonsCount = Wagon::where('is_settled', false)->count();
        $editedWagonsTotal = Wagon::ownerEdited()->count();
        $editedWagonsInRange = Wagon::ownerEdited()->whereBetween('owner_changed_at', [$from, $to])->count();

        $kpis = [
            'total_requests' => CargoRequest::whereBetween('request_date', [$from, $to])->count(),
            'total_billings' => (int) ($billingAggregates->total_billings ?? 0),
            'total_amount' => (int) ($billingAggregates->total_amount ?? 0),
            'pending_wagons' => $pendingWagonsCount,
            'loaded_wagons' => Wagon::whereNotNull('loaded_weight')->where('is_settled', false)->count(),
            'active_owners' => Owner::active()->count(),
            'active_representatives' => Representative::active()->count(),
            'edited_wagons' => $editedWagonsTotal,
            'edited_wagons_in_range' => $editedWagonsInRange,
        ];

        $loadingChart = $this->dailyLoading($from, $to);
        $revenueChart = $this->dailyRevenue($from, $to);

        $ownerShareChart = DB::table('billing_items')
            ->join('billings', 'billings.id', '=', 'billing_items.billing_id')
            ->leftJoin('wagons', 'wagons.id', '=', 'billing_items.wagon_id')
            ->join('owners', function ($join) {
                $join->whereRaw('owners.id = COALESCE(wagons.owner_id, billings.owner_id)');
            })
            ->whereBetween('billings.billing_date', [$from, $to])
            ->where('billings.status', Billing::STATUS_ISSUED)
            ->whereNull('billings.deleted_at')
            ->selectRaw('owners.name, SUM(billing_items.total_amount) as total')
            ->groupBy('owners.id', 'owners.name')
            ->orderByDesc('total')
            ->limit(8)
            ->get();

        $recentBillings = Billing::with('owner')->latest('billing_date')->latest('id')->limit(10)->get();

        $wagonStats = [
            'loaded' => Wagon::whereNotNull('loaded_weight')->count(),
            'settled' => Wagon::where('is_settled', true)->count(),
            'pending' => $pendingWagonsCount,
            'edited' => $editedWagonsTotal,
            'number_edited' => Wagon::numberEdited()->count(),
            'owner_edited' => Wagon::onlyOwnerChanged()->count(),
            'edited_in_range' => $editedWagonsInRange,
            'total_edit_logs' => WagonOwnerLog::count(),
        ];

        $editedWagons = Wagon::ownerEdited()
            ->with([
                'owner',
                'previousOwner',
                'ownerChangedBy',
                'cargoRequest.owner',
                'billingItem.billing',
            ])
            ->orderByDesc('owner_changed_at')
            ->orderByDesc('id')
            ->limit(25)
            ->get();

        if (in_array(strtolower((string) $request->query('export', '')), ['edited_wagons', 'excel', 'xlsx', '1'], true)) {
            $allEdited = Wagon::ownerEdited()
                ->with([
                    'owner',
                    'previousOwner',
                    'ownerChangedBy',
                    'cargoRequest.owner',
                    'billingItem.billing',
                ])
                ->orderByDesc('owner_changed_at')
                ->orderByDesc('id')
                ->lazy(500);

            $rows = [];
            foreach ($allEdited as $idx => $wagon) {
                $rows[] = [
                    $idx + 1,
                    $wagon->wagon_number,
                    $wagon->isNumberEdited() ? $wagon->previous_wagon_number : '—',
                    $wagon->editTypeLabel(),
                    $wagon->cargo_description ?: '—',
                    $wagon->cargoRequest?->request_number ?? '—',
                    $wagon->billingItem?->billing?->billing_number ?? '—',
                    $wagon->isOwnerChanged() ? ($wagon->previousOwner?->name ?? '—') : '—',
                    $wagon->ownerName(),
                    $wagon->owner_change_note ?: '—',
                    $wagon->ownerChangedBy?->name ?? '—',
                    $wagon->owner_changed_at
                        ? Jalalian::fromCarbon(Carbon::instance($wagon->owner_changed_at))->format('Y/m/d H:i')
                        : '—',
                    (int) $wagon->owner_change_count,
                ];
            }

            return ExcelExport::download(
                'edited-wagons-'.JalaliDate::today('Y-m-d').'.xlsx',
                'فهرست واگن‌های ویرایش‌شده (شماره واگن / صاحب کالا)',
                [
                    'ردیف',
                    'شماره واگن فعلی',
                    'شماره واگن قبلی',
                    'نوع ویرایش',
                    'شرح کالا',
                    'شماره درخواست',
                    'شماره صورتحساب',
                    'صاحب کالای قبلی',
                    'صاحب کالای فعلی',
                    'علت و توضیحات ویرایش',
                    'کاربر ویرایش‌کننده',
                    'زمان آخرین ویرایش',
                    'تعداد دفعات ویرایش',
                ],
                $rows,
                [
                    'جمع کل',
                    count($rows).' واگن ویرایش‌شده',
                    'اصلاح شماره: '.($wagonStats['number_edited'] ?? 0),
                    'تغییر صاحب کالا: '.($wagonStats['owner_edited'] ?? 0),
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    (int) ($wagonStats['total_edit_logs'] ?? 0),
                ]
            );
        }

        return view('dashboard.index', [
            'kpis' => $kpis,
            'loadingChart' => $loadingChart,
            'revenueChart' => $revenueChart,
            'ownerShareChart' => $ownerShareChart,
            'recentBillings' => $recentBillings,
            'wagonStats' => $wagonStats,
            'editedWagons' => $editedWagons,
            'fromShamsi' => JalaliDate::fromCarbon($from),
            'toShamsi' => JalaliDate::fromCarbon($to),
        ]);
    }

    /**
     * @return array{0: Carbon, 1: Carbon}
     */
    private function resolveDateRange(Request $request): array
    {
        $from = $request->filled('from') ? JalaliDate::parse($request->string('from')->toString(), 'from') : null;
        $to = $request->filled('to') ? JalaliDate::parse($request->string('to')->toString(), 'to') : null;

        $from ??= now()->subDays(6)->startOfDay();
        $to ??= now()->endOfDay();

        if ($from->greaterThan($to)) {
            [$from, $to] = [$to->copy()->startOfDay(), $from->copy()->endOfDay()];
        }

        return [$from, $to];
    }

    /**
     * @return array{labels: array<int, string>, values: array<int, float>}
     */
    private function dailyLoading(Carbon $from, Carbon $to): array
    {
        [$start, $end] = $this->clampChartRange($from, $to);

        $grouped = DB::table('wagons')
            ->whereBetween('loaded_on', [$start->toDateString(), $end->toDateString()])
            ->selectRaw('loaded_on as day_key, COALESCE(SUM(loaded_weight), 0) as total_value')
            ->groupBy('loaded_on')
            ->pluck('total_value', 'day_key');

        return $this->formatDailySeries($start, $end, $grouped, fn (float $value) => round($value, 1));
    }

    /**
     * @return array{labels: array<int, string>, values: array<int, float>}
     */
    private function dailyRevenue(Carbon $from, Carbon $to): array
    {
        [$start, $end] = $this->clampChartRange($from, $to);

        $grouped = Billing::query()
            ->whereBetween('billing_date', [$start->toDateString(), $end->toDateString()])
            ->where('status', Billing::STATUS_ISSUED)
            ->selectRaw('billing_date as day_key, COALESCE(SUM(total_amount), 0) as total_value')
            ->groupBy('billing_date')
            ->pluck('total_value', 'day_key');

        return $this->formatDailySeries($start, $end, $grouped, fn (float $value) => $value);
    }

    /**
     * @return array{0: Carbon, 1: Carbon}
     */
    private function clampChartRange(Carbon $from, Carbon $to): array
    {
        $end = $to->copy()->endOfDay();
        $start = $from->copy()->startOfDay();

        if ($start->diffInDays($end) > self::MAX_CHART_DAYS) {
            $start = $end->copy()->subDays(self::MAX_CHART_DAYS)->startOfDay();
        }

        return [$start, $end];
    }

    /**
     * ساخت سری روزانه از نتیجه یک کوئری تجمیعی GROUP BY.
     *
     * @param  \Illuminate\Support\Collection<string, mixed>  $grouped
     * @return array{labels: array<int, string>, values: array<int, float>}
     */
    private function formatDailySeries(Carbon $start, Carbon $end, $grouped, callable $cast): array
    {
        $labels = [];
        $values = [];

        for ($day = $start->copy(); $day->lessThanOrEqualTo($end); $day->addDay()) {
            $dateStr = $day->toDateString();
            $labels[] = JalaliDate::fromCarbon($day);
            $values[] = $cast((float) ($grouped->get($dateStr) ?? 0));
        }

        return compact('labels', 'values');
    }
}
