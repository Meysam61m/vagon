<?php

namespace App\Http\Controllers;

use App\Models\Billing;
use App\Models\BillingItem;
use App\Models\CargoRequest;
use App\Models\Owner;
use App\Models\Representative;
use App\Models\Tariff;
use App\Models\TaxSetting;
use App\Models\Wagon;
use App\Support\DocumentNumber;
use App\Support\JalaliDate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BillingController extends Controller
{
    public function index(Request $request)
    {
        $billings = Billing::with([
            'owner',
            'representative',
            'operator',
            'items.wagon.owner',
            'items.wagon.cargoRequest.wagons.billingItem.billing',
        ])
            ->when($request->filled('owner_id'), function ($q) use ($request) {
                $ownerId = $request->integer('owner_id');

                $q->where(function ($sub) use ($ownerId) {
                    $sub->where('owner_id', $ownerId)
                        ->orWhereHas('items.wagon', fn ($w) => $w->where('owner_id', $ownerId));
                });
            })
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')->toString()))
            ->when($request->filled('search'), function ($q) use ($request) {
                $term = '%'.trim($request->string('search')->toString()).'%';

                $q->where(function ($inner) use ($term) {
                    $inner->where('billing_number', 'like', $term)
                        ->orWhere('owner_name', 'like', $term)
                        ->orWhereHas('items.wagon', fn ($w) => $w
                            ->where('wagon_number', 'like', $term)
                            ->orWhere('previous_wagon_number', 'like', $term)
                            ->orWhereHas('owner', fn ($wo) => $wo->where('name', 'like', $term)));
                });
            })
            ->latest('billing_date')
            ->latest('id')
            ->paginate(15)
            ->withQueryString();

        return view('billing.index', [
            'billings' => $billings,
            'owners' => Owner::orderBy('name')->get(['id', 'name']),
            'statusLabels' => Billing::STATUS_LABELS,
        ]);
    }

    public function create(Request $request)
    {
        $owners = Owner::active()->orderBy('name')->get();
        $ownerId = $request->integer('owner_id') ?: null;
        $selectedCargoRequestId = $request->integer('cargo_request_id') ?: null;
        $defaultRepresentativeId = $request->integer('representative_id') ?: null;

        if ($selectedCargoRequestId && ! $ownerId) {
            $cr = CargoRequest::find($selectedCargoRequestId);
            if ($cr) {
                $ownerId = $cr->owner_id ? (int) $cr->owner_id : null;
                $defaultRepresentativeId = $defaultRepresentativeId ?: (int) $cr->representative_id;
            }
        }

        // شمارش واگن‌های بارگیری‌شده و تسویه‌نشده هر صاحب کالا برای دسترسی سریع اپراتور
        $pendingWagonsForCounts = Wagon::query()
            ->pendingSettlement()
            ->loaded()
            ->with('cargoRequest:id,owner_id')
            ->get(['id', 'owner_id', 'cargo_request_id']);

        $readyCountsByOwner = $pendingWagonsForCounts
            ->toBase()
            ->countBy(fn (Wagon $w) => (int) ($w->effectiveOwnerId() ?? 0));

        $unknownOwnerReadyCount = (int) ($readyCountsByOwner->get(0) ?? 0);

        $unassignedWagons = Wagon::query()
            ->pendingSettlement()
            ->loaded()
            ->whereNull('owner_id')
            ->whereHas('cargoRequest', fn ($cr) => $cr->whereNull('owner_id'))
            ->with(['cargoRequest.representative.owners', 'owner', 'tariff'])
            ->orderBy('wagon_number')
            ->get();

        $wagons = collect();
        $representatives = collect();

        if ($ownerId) {
            $wagons = Wagon::query()
                ->pendingSettlement()
                ->loaded()
                ->where(function ($q) use ($ownerId) {
                    $q->where('owner_id', $ownerId)
                        ->orWhere(function ($sub) use ($ownerId) {
                            $sub->whereNull('owner_id')
                                ->whereHas('cargoRequest', function ($cr) use ($ownerId) {
                                    $cr->where('owner_id', $ownerId)
                                        ->orWhere(function ($unk) use ($ownerId) {
                                            $unk->whereNull('owner_id')
                                                ->whereHas('representative.owners', fn ($oq) => $oq->where('owners.id', $ownerId));
                                        });
                                });
                        });
                })
                ->with(['cargoRequest.representative', 'owner', 'tariff'])
                ->orderByRaw('CASE WHEN owner_id = ? THEN 0 ELSE 1 END', [$ownerId])
                ->orderBy('wagon_number')
                ->get();

            $representatives = Representative::active()
                ->whereHas('owners', fn ($q) => $q->where('owners.id', $ownerId))
                ->orderBy('name')
                ->get();

            if (! $defaultRepresentativeId) {
                $validRepIds = $representatives->pluck('id')->all();
                $wagonRepIds = $wagons
                    ->pluck('cargoRequest.representative_id')
                    ->filter(fn ($rid) => in_array((int) $rid, $validRepIds, true))
                    ->unique()
                    ->values();

                if ($wagonRepIds->count() === 1) {
                    $defaultRepresentativeId = (int) $wagonRepIds->first();
                } elseif ($representatives->count() === 1) {
                    $defaultRepresentativeId = (int) $representatives->first()->id;
                }
            }
        }

        return view('billing.create', [
            'owners' => $owners,
            'readyCountsByOwner' => $readyCountsByOwner,
            'unknownOwnerReadyCount' => $unknownOwnerReadyCount,
            'unassignedWagons' => $unassignedWagons,
            'ownerId' => $ownerId,
            'selectedCargoRequestId' => $selectedCargoRequestId,
            'defaultRepresentativeId' => $defaultRepresentativeId,
            'wagons' => $wagons,
            'tariffs' => Tariff::active()->orderBy('title')->get(),
            'taxPercentage' => TaxSetting::currentPercentage(),
            'representatives' => $representatives,
            'allRepresentatives' => Representative::active()->orderBy('name')->get(['id', 'name']),
            'billingDateShamsi' => JalaliDate::today(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'owner_id' => ['required', 'integer', 'exists:owners,id'],
            'representative_id' => ['required', 'integer', 'exists:representatives,id'],
            'billing_date_shamsi' => ['required', 'string'],
            'wagons' => ['required', 'array', 'min:1'],
            'wagons.*.id' => ['required', 'integer', 'distinct', 'exists:wagons,id'],
            'wagons.*.tariff_id' => ['required', 'integer', 'exists:tariffs,id'],
            'wagons.*.weight' => ['required', 'numeric', 'min:0.01', 'max:200'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ], [
            'owner_id.required' => 'هنگام صدور صورتحساب، انتخاب نام صاحب کالا الزامی است.',
            'representative_id.required' => 'هنگام صدور صورتحساب، انتخاب نام نماینده الزامی است.',
        ], [
            'owner_id' => 'صاحب کالا',
            'representative_id' => 'نماینده',
            'billing_date_shamsi' => 'تاریخ صدور',
            'wagons' => 'واگن‌ها',
        ]);

        $linked = DB::table('owner_representative')
            ->where('owner_id', $data['owner_id'])
            ->where('representative_id', $data['representative_id'])
            ->exists();

        if (! $linked) {
            throw ValidationException::withMessages([
                'representative_id' => 'این نماینده به صاحب کالای انتخاب‌شده تخصیص داده نشده است.',
            ]);
        }

        $billingDate = JalaliDate::parse($data['billing_date_shamsi'], 'billing_date_shamsi');
        $billingDateShamsi = JalaliDate::normalize($data['billing_date_shamsi']);

        $billing = DocumentNumber::withRetry(function () use ($data, $billingDate, $billingDateShamsi) {
            $taxPercentage = TaxSetting::currentPercentage();
            $owner = Owner::findOrFail($data['owner_id']);
            $representativeId = $data['representative_id'] ?? null;
            $representative = $representativeId ? Representative::find($representativeId) : null;

            $rows = collect($data['wagons']);
            $ids = $rows->pluck('id')->all();

            // قفل ردیف‌های واگن تا دو درخواست هم‌زمان نتوانند یک واگن را دوبار فاکتور کنند
            /** @var \Illuminate\Support\Collection<int, Wagon> $wagons */
            $wagons = Wagon::with('cargoRequest.representative')
                ->whereIn('id', $ids)
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            if ($wagons->count() !== count($ids)) {
                throw ValidationException::withMessages([
                    'wagons' => 'برخی از واگن‌های انتخاب‌شده وجود ندارند.',
                ]);
            }

            $tariffs = Tariff::whereIn('id', $rows->pluck('tariff_id')->unique()->all())
                ->get()
                ->keyBy('id');

            $items = [];
            $baseAmount = 0;
            $taxAmount = 0;

            foreach ($rows as $row) {
                /** @var Wagon $wagon */
                $wagon = $wagons->get($row['id']);

                if ($wagon->is_settled) {
                    throw ValidationException::withMessages([
                        'wagons' => "واگن {$wagon->wagon_number} قبلاً تسویه/صورتحساب شده است.",
                    ]);
                }

                $effectiveOwnerId = $wagon->effectiveOwnerId();
                if ($effectiveOwnerId !== null && (int) $effectiveOwnerId !== (int) $owner->id) {
                    throw ValidationException::withMessages([
                        'wagons' => "واگن {$wagon->wagon_number} متعلق به صاحب کالای دیگری است.",
                    ]);
                }

                // بررسی الزامی رابطه صاحب کالا و نماینده ثبت‌شده در درخواست بارگیری واگن
                $wagonRepId = (int) ($wagon->cargoRequest?->representative_id ?? 0);
                if ($wagonRepId > 0) {
                    $wagonRepLinked = DB::table('owner_representative')
                        ->where('owner_id', $owner->id)
                        ->where('representative_id', $wagonRepId)
                        ->exists();

                    if (! $wagonRepLinked) {
                        $repName = $wagon->cargoRequest?->representative?->name ?? 'نماینده درخواست';
                        throw ValidationException::withMessages([
                            'wagons' => "نماینده واگن {$wagon->wagon_number} («{$repName}») به صاحب کالای «{$owner->name}» تخصیص داده نشده است.",
                        ]);
                    }
                }

                if (! $wagon->isLoaded()) {
                    throw ValidationException::withMessages([
                        'wagons' => "برای واگن {$wagon->wagon_number} هنوز وزن بارگیری ثبت نشده است.",
                    ]);
                }

                /** @var Tariff|null $tariff */
                $tariff = $tariffs->get($row['tariff_id']);

                if (! $tariff) {
                    throw ValidationException::withMessages([
                        'wagons' => 'تعرفه انتخاب‌شده معتبر نیست.',
                    ]);
                }

                $weight = (float) $row['weight'];

                if ($weight > (float) $tariff->capacity) {
                    throw ValidationException::withMessages([
                        'wagons' => "وزن واگن {$wagon->wagon_number} از ظرفیت تعرفه ({$tariff->capacity} تن) بیشتر است.",
                    ]);
                }

                $baseCost = BillingItem::calculateBaseCost($weight, (float) $tariff->capacity, (float) $tariff->rate);
                $itemTax = BillingItem::calculateTax($baseCost, $taxPercentage);

                $baseAmount += $baseCost;
                $taxAmount += $itemTax;

                $items[] = [
                    'wagon_id' => $wagon->id,
                    'tariff_id' => $tariff->id,
                    'tariff_title' => $tariff->title,
                    'tariff_rate' => $tariff->rate,
                    'tariff_capacity' => $tariff->capacity,
                    'loaded_weight' => $weight,
                    'base_cost' => $baseCost,
                    'tax_amount' => $itemTax,
                    'total_amount' => $baseCost + $itemTax,
                ];
            }

            $billing = Billing::create([
                'billing_number' => Billing::generateBillingNumber(),
                'owner_id' => $owner->id,
                'representative_id' => $representative?->id,
                'operator_id' => auth()->id(),
                'owner_name' => $owner->name,
                'representative_name' => $representative?->name,
                'billing_date' => $billingDate->toDateString(),
                'billing_date_shamsi' => $billingDateShamsi,
                'base_amount' => $baseAmount,
                'tax_percentage' => $taxPercentage,
                'tax_amount' => $taxAmount,
                'total_amount' => $baseAmount + $taxAmount,
                'status' => Billing::STATUS_ISSUED,
                'notes' => $data['notes'] ?? null,
            ]);

            foreach ($items as $item) {
                $billing->items()->create($item);

                Wagon::where('id', $item['wagon_id'])->update([
                    'is_settled' => true,
                    'owner_id' => $owner->id,
                    'tariff_id' => $item['tariff_id'],
                    'loaded_weight' => $item['loaded_weight'],
                ]);
            }

            // به‌روزرسانی وضعیت درخواست‌های بارگیری متأثر
            $cargoIds = $wagons->pluck('cargoRequest.id')->unique()->filter();

            foreach ($cargoIds as $cargoId) {
                $cargo = CargoRequest::with('wagons')->find($cargoId);

                if (! $cargo) {
                    continue;
                }

                $cargoUpdates = [];

                if (! $cargo->owner_id) {
                    $allHaveSameOrNullOwner = $cargo->wagons->every(
                        fn (Wagon $w) => $w->owner_id === null || (int) $w->owner_id === (int) $owner->id
                    );
                    if ($allHaveSameOrNullOwner) {
                        $cargoUpdates['owner_id'] = $owner->id;
                    }
                }

                if ($cargo->wagons->every(fn (Wagon $wagon) => $wagon->is_settled)) {
                    $cargoUpdates['status'] = CargoRequest::STATUS_BILLED;
                } elseif ($cargo->allWagonsLoaded()) {
                    $cargoUpdates['status'] = CargoRequest::STATUS_LOADED;
                }

                if (! empty($cargoUpdates)) {
                    $cargo->update($cargoUpdates);
                }
            }

            return $billing;
        });

        return redirect()
            ->route('billing.show', $billing)
            ->with('success', 'صورتحساب با موفقیت صادر شد. لطفاً اطلاعات فیش واریزی را وارد و تسویه حساب را ثبت کنید تا برگه ۴ بخشی چاپ شود.');
    }

    /**
     * ثبت اطلاعات فیش واریزی و تسویه حساب صورتحساب و هدایت مستقیم به صفحه چاپ برگه ۴ بخشی
     */
    public function settle(Request $request, Billing $billing)
    {
        if ($billing->isCancelled()) {
            return redirect()
                ->route('billing.show', $billing)
                ->with('error', 'این صورتحساب لغو شده است و امکان ثبت فیش واریزی برای آن وجود ندارد.');
        }

        $data = $request->validate([
            'receipt_number' => ['required', 'string', 'max:100'],
            'receipt_date_shamsi' => ['required', 'string', 'max:20'],
            'bank_name' => ['nullable', 'string', 'max:100'],
            'receipt_amount' => ['nullable', 'numeric', 'min:0'],
        ], [
            'receipt_number.required' => 'وارد کردن شماره فیش واریزی / کد رهگیری الزامی است.',
            'receipt_date_shamsi.required' => 'وارد کردن تاریخ فیش واریزی الزامی است.',
        ], [
            'receipt_number' => 'شماره فیش واریزی',
            'receipt_date_shamsi' => 'تاریخ فیش واریزی',
            'bank_name' => 'نام بانک / روش واریز',
            'receipt_amount' => 'مبلغ فیش واریزی',
        ]);

        JalaliDate::parse($data['receipt_date_shamsi'], 'receipt_date_shamsi');
        $receiptDateShamsi = JalaliDate::normalize($data['receipt_date_shamsi']);

        $billing->update([
            'receipt_number' => trim($data['receipt_number']),
            'receipt_date_shamsi' => $receiptDateShamsi,
            'bank_name' => ! empty($data['bank_name']) ? trim($data['bank_name']) : null,
            'receipt_amount' => isset($data['receipt_amount']) && $data['receipt_amount'] !== ''
                ? (int) round((float) $data['receipt_amount'])
                : (int) $billing->total_amount,
            'settled_at' => $billing->settled_at ?? now(),
        ]);

        $billing->load(['items.wagon.cargoRequest.wagons.billingItem.billing']);

        $cargoRequests = $billing->items
            ->map(fn ($item) => $item->wagon?->cargoRequest)
            ->filter()
            ->unique('id')
            ->values();

        $fullySettledCargo = $cargoRequests->first(fn (CargoRequest $c) => $c->allWagonsFullySettled());

        if ($fullySettledCargo) {
            return redirect()
                ->route('billing.print', ['billing' => $billing->id, 'cargo_request_id' => $fullySettledCargo->id])
                ->with('success', "همه واگن‌های درخواست بارگیری «{$fullySettledCargo->request_number}» تسویه شدند؛ آماده چاپ برگه ۴ بخشی.");
        }

        $firstCargo = $cargoRequests->first();
        if ($firstCargo) {
            $settledCount = $firstCargo->fullySettledWagonsCount();
            $totalCount = $firstCargo->wagons->count();

            return redirect()
                ->route('billing.show', $billing)
                ->with('warning', "اطلاعات فیش واریزی برای صورتحساب «{$billing->billing_number}» ثبت شد؛ اما از مجموع {$totalCount} واگنِ درخواست بارگیری «{$firstCargo->request_number}»، تاکنون {$settledCount} واگن تسویه شده است. چاپ برگه ۴ بخشی به محض تسویه تمام واگن‌های این شماره درخواست انجام خواهد شد.");
        }

        return redirect()
            ->route('billing.print', $billing)
            ->with('success', 'اطلاعات فیش واریزی و تسویه حساب ثبت شد؛ آماده چاپ برگه ۴ بخشی.');
    }

    public function show(Billing $billing)
    {
        $billing->load([
            'items.wagon.owner',
            'items.wagon.previousOwner',
            'items.wagon.ownerChangedBy',
            'items.wagon.cargoRequest.wagons.billingItem.billing',
            'items.tariff',
            'representative',
        ]);

        return view('billing.show', [
            'billing' => $billing,
            'todayShamsi' => JalaliDate::today(),
        ]);
    }

    public function print(Request $request, Billing $billing)
    {
        if ($billing->isCancelled()) {
            return redirect()
                ->route('billing.show', $billing)
                ->with('error', 'امکان چاپ برگه تسویه برای صورتحساب لغوشده وجود ندارد.');
        }

        if (! $billing->isSettled()) {
            return redirect()
                ->route('billing.show', $billing)
                ->with('warning', 'برای چاپ برگه ۴ بخشی تسویه حساب، ابتدا اطلاعات فیش واریزی را وارد و تسویه حساب را ثبت نمایید.');
        }

        $billing->load([
            'items.wagon.owner',
            'items.wagon.previousOwner',
            'items.wagon.cargoRequest.owner',
            'items.wagon.cargoRequest.representative',
            'items.wagon.cargoRequest.operator',
            'items.wagon.cargoRequest.wagons.owner',
            'items.wagon.cargoRequest.wagons.tariff',
            'items.wagon.cargoRequest.wagons.billingItem.billing.operator',
            'items.wagon.cargoRequest.wagons.billingItem.billing.representative',
            'items.tariff',
            'representative',
            'operator',
        ]);

        $cargoRequests = $billing->items
            ->map(fn ($item) => $item->wagon?->cargoRequest)
            ->filter()
            ->unique('id')
            ->values();

        $requestedCargoId = $request->integer('cargo_request_id');
        $cargo = $requestedCargoId > 0
            ? $cargoRequests->firstWhere('id', $requestedCargoId)
            : ($cargoRequests->first(fn (CargoRequest $c) => $c->allWagonsFullySettled()) ?? $cargoRequests->first());

        if ($cargo && ! $cargo->allWagonsFullySettled()) {
            $settledCount = $cargo->fullySettledWagonsCount();
            $totalCount = $cargo->wagons->count();

            return redirect()
                ->route('billing.show', $billing)
                ->with('warning', "ملاک چاپ برگه ۴ بخشی، تسویه کامل همه واگن‌های شماره درخواست است. در درخواست بارگیری «{$cargo->request_number}» از مجموع {$totalCount} واگن، تاکنون {$settledCount} واگن تسویه شده است.");
        }

        return view('billing.print', [
            'billing' => $billing,
            'cargo' => $cargo,
        ]);
    }

    /**
     * لغو صورتحساب: ردیف‌ها حذف و واگن‌ها آزاد می‌شوند تا امکان صدور مجدد فراهم باشد.
     */
    public function cancel(Billing $billing)
    {
        if ($billing->isCancelled()) {
            return back()->with('warning', 'این صورتحساب قبلاً لغو شده است.');
        }

        DB::transaction(function () use ($billing) {
            $billing->load('items.wagon');

            $wagonIds = $billing->items->pluck('wagon_id')->unique()->values();
            $cargoIds = $billing->items->pluck('wagon.cargo_request_id')->unique()->filter();

            $billing->items()->delete();

            Wagon::whereIn('id', $wagonIds)->update(['is_settled' => false]);

            $billing->update([
                'status' => Billing::STATUS_CANCELLED,
                'cancelled_at' => now(),
            ]);

            foreach ($cargoIds as $cargoId) {
                $cargo = CargoRequest::with('wagons')->find($cargoId);

                if (! $cargo) {
                    continue;
                }

                $cargo->update([
                    'status' => $cargo->allWagonsLoaded()
                        ? CargoRequest::STATUS_LOADED
                        : CargoRequest::STATUS_PENDING,
                ]);
            }
        });

        return redirect()
            ->route('billing.show', $billing)
            ->with('success', 'صورتحساب لغو شد و واگن‌ها برای صدور مجدد آزاد شدند.');
    }
}
