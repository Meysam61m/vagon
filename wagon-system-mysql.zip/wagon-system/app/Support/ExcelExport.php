<?php

namespace App\Support;

use Symfony\Component\HttpFoundation\Response;

/**
 * تولیدکننده بومی فایل اکسل استاندارد (.xlsx - Office Open XML) بدون وابستگی به پکیج خارجی یا افزونه خاص PHP.
 * فایل خروجی کاملاً راست‌به‌چپ (RTL)، دارای هدر رنگی، ردیف جمع کل، قالب‌بندی اعداد و عرض خودکار ستون‌هاست.
 */
class ExcelExport
{
    /**
     * ساخت و ارسال پاسخ دانلود فایل `.xlsx`
     *
     * @param  string  $filename  نام فایل (بدون یا با پسوند .xlsx)
     * @param  string  $sheetTitle  عنوان شیت و بنر بالای جدول
     * @param  array<int, string>  $headers  عناوین ستون‌ها
     * @param  iterable<int, array<int, mixed>>  $rows  ردیف‌های داده
     * @param  array<int, mixed>|null  $TotalsRow  ردیف جمع کل در انتهای جدول (اختیاری)
     */
    public static function download(
        string $filename,
        string $sheetTitle,
        array $headers,
        iterable $rows,
        ?array $totalsRow = null
    ): Response {
        if (! str_ends_with(strtolower($filename), '.xlsx')) {
            $filename .= '.xlsx';
        }

        $xlsxBinary = self::buildXlsx($sheetTitle, array_values($headers), $rows, $totalsRow);

        $safeAsciiName = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) ?: 'report.xlsx';
        $encodedName = rawurlencode($filename);

        return new Response($xlsxBinary, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => "attachment; filename=\"{$safeAsciiName}\"; filename*=UTF-8''{$encodedName}",
            'Content-Length' => (string) strlen($xlsxBinary),
            'Cache-Control' => 'max-age=0, no-cache, no-store, must-revalidate',
            'Pragma' => 'public',
        ]);
    }

    /**
     * ساخت و ارسال فایل اکسل «گزارش ستاد» دقیقاً مطابق قالب و فرمول‌های فایل نمونه
     * (لیست واگن‌های فاز ۲ شهید مطهری با ستون‌های B تا M، ستون سبز مبلغ تعرفه کتابچه و امضاهای انتهای صفحه).
     *
     * @param  string  $filename
     * @param  string  $fromShamsi
     * @param  string  $toShamsi
     * @param  iterable<int, array<string, mixed>>  $itemsData
     */
    public static function downloadSetadReport(
        string $filename,
        string $fromShamsi,
        string $toShamsi,
        iterable $itemsData
    ): Response {
        if (! str_ends_with(strtolower($filename), '.xlsx')) {
            $filename .= '.xlsx';
        }

        $xlsxBinary = self::buildSetadXlsx($fromShamsi, $toShamsi, $itemsData);

        $safeAsciiName = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) ?: 'setad-report.xlsx';
        $encodedName = rawurlencode($filename);

        return new Response($xlsxBinary, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => "attachment; filename=\"{$safeAsciiName}\"; filename*=UTF-8''{$encodedName}",
            'Content-Length' => (string) strlen($xlsxBinary),
            'Cache-Control' => 'max-age=0, no-cache, no-store, must-revalidate',
            'Pragma' => 'public',
        ]);
    }

    /**
     * @param  iterable<int, array<string, mixed>>  $itemsData
     */
    public static function buildSetadXlsx(string $fromShamsi, string $toShamsi, iterable $itemsData): string
    {
        $title = "لیست واگن های فاز 2 شهید مطهری در بازه زمانی {$fromShamsi} لغایت {$toShamsi}";

        $files = [
            '[Content_Types].xml' => self::contentTypesXml(),
            '_rels/.rels' => self::rootRelsXml(),
            'xl/_rels/workbook.xml.rels' => self::workbookRelsXml(),
            'xl/workbook.xml' => self::workbookXml('Sheet1'),
            'xl/styles.xml' => self::setadStylesXml(),
            'xl/worksheets/sheet1.xml' => self::setadSheetXml($title, $itemsData),
        ];

        return self::buildZipArchive($files);
    }

    private static function setadStylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            .'<numFmts count="2">'
            .'<numFmt numFmtId="164" formatCode="_ * #,##0.00_-_ ;_ * #,##0.00\-_ ;_ * &quot;-&quot;??_-_ ;_ @_ "/>'
            .'<numFmt numFmtId="165" formatCode="_ * #,##0_-_ ;_ * #,##0\-_ ;_ * &quot;-&quot;??_-_ ;_ @_ "/>'
            .'</numFmts>'
            .'<fonts count="3">'
            // 0: Arial 11
            .'<font><sz val="11"/><color rgb="FF000000"/><name val="Arial"/><family val="2"/></font>'
            // 1: B Nazanin 11 Bold
            .'<font><b/><sz val="11"/><color rgb="FF000000"/><name val="B Nazanin"/><charset val="178"/></font>'
            // 2: B Nazanin 12 Bold (Title)
            .'<font><b/><sz val="12"/><color rgb="FF000000"/><name val="B Nazanin"/><charset val="178"/></font>'
            .'</fonts>'
            .'<fills count="4">'
            .'<fill><patternFill patternType="none"/></fill>'
            .'<fill><patternFill patternType="gray125"/></fill>'
            .'<fill><patternFill patternType="solid"><fgColor rgb="FFFFFFFF"/><bgColor indexed="64"/></patternFill></fill>'
            .'<fill><patternFill patternType="solid"><fgColor rgb="FF92D050"/><bgColor indexed="64"/></patternFill></fill>'
            .'</fills>'
            .'<borders count="3">'
            .'<border><left/><right/><top/><bottom/><diagonal/></border>'
            .'<border>'
            .'<left style="thin"><color rgb="FF000000"/></left>'
            .'<right style="thin"><color rgb="FF000000"/></right>'
            .'<top style="thin"><color rgb="FF000000"/></top>'
            .'<bottom style="thin"><color rgb="FF000000"/></bottom>'
            .'<diagonal/>'
            .'</border>'
            .'<border>'
            .'<left/><right/><top/><bottom style="thin"><color rgb="FF000000"/></bottom><diagonal/>'
            .'</border>'
            .'</borders>'
            .'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            .'<cellXfs count="8">'
            // 0: پیش‌فرض خالی
            .'<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            // 1: عنوان بالای جدول (B1:M1) - B Nazanin 12 Bold با خط زیرین
            .'<xf numFmtId="0" fontId="2" fillId="0" borderId="2" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 2: سرستون‌ها (B2:M2) - B Nazanin 11 Bold با کادر کامل
            .'<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 3: سلول متنی/ردیف وسط‌چین با کادر (B, C, D, E, H, L, M)
            .'<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 4: سلول عددی/مبلغ با فرمت #,##0 و کادر (F, G, J, K)
            .'<xf numFmtId="165" fontId="1" fillId="2" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 5: سلول سبز «مبلغ تعرفه در کتابچه» (ستون I) با پس‌زمینه #92D050 و فرمت #,##0
            .'<xf numFmtId="165" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 6: سلول توضیحات طولانی با wrapText (ستون M در محاسبه تناژی)
            .'<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 7: امضاهای پایین جدول (B Nazanin 11 Bold بدون کادر)
            .'<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            .'</cellXfs>'
            .'</styleSheet>';
    }

    /**
     * @param  iterable<int, array<string, mixed>>  $itemsData
     */
    private static function setadSheetXml(string $title, iterable $itemsData): string
    {
        $headers = [
            'B' => 'ردیف',
            'C' => 'شماره واگن',
            'D' => 'شرح کالا',
            'E' => 'عنوان تعرفه استفاده شده',
            'F' => 'مبلغ تعرفه',
            'G' => 'نام صاحب کالا',
            'H' => 'مبلغ با احتساب مالیات بر ارزش افزوده',
            'I' => 'مبلغ کل قابل دریافت از مشتری',
            'J' => 'توضیحات/ شماره وسیله حمل',
            'K' => 'مبلغ تعرفه در کتابچه',
            'L' => 'تناژ (عملیاتی)',
            'M' => 'محاسبه بر اساس کتابچه تعرفه',
            'N' => 'نحوه محاسبه',
            'O' => 'توضیحات',
        ];

        $widths = [
            1 => 2.25,    // A (ستون حاشیه)
            2 => 10,      // B: ردیف
            3 => 14.5,    // C: شماره واگن
            4 => 16.5,    // D: شرح کالا
            5 => 32,      // E: عنوان تعرفه استفاده شده
            6 => 20,      // F: مبلغ تعرفه
            7 => 24,      // G: نام صاحب کالا
            8 => 20,      // H: مبلغ با احتساب مالیات بر ارزش افزوده
            9 => 23,      // I: مبلغ کل قابل دریافت از مشتری
            10 => 29.5,   // J: توضیحات/ شماره وسیله حمل
            11 => 22,     // K: مبلغ تعرفه در کتابچه
            12 => 18.75,  // L: تناژ (عملیاتی)
            13 => 24,     // M: محاسبه بر اساس کتابچه تعرفه
            14 => 22,     // N: نحوه محاسبه
            15 => 28,     // O: توضیحات
        ];

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            .'<sheetViews><sheetView rightToLeft="1" tabSelected="1" workbookViewId="0"/></sheetViews>'
            .'<sheetFormatPr defaultRowHeight="19.5"/>'
            .'<cols>';

        foreach ($widths as $colIdx => $w) {
            $xml .= '<col min="'.$colIdx.'" max="'.$colIdx.'" width="'.$w.'" customWidth="1"/>';
        }

        $xml .= '</cols><sheetData>';

        // ردیف ۱: بنر عنوان (B1:O1 ادغام‌شده)
        $xml .= '<row r="1" ht="26.25" customHeight="1">';
        foreach (array_keys($headers) as $colLetter) {
            if ($colLetter === 'B') {
                $xml .= '<c r="B1" s="1" t="inlineStr"><is><t>'.self::xmlEscape($title).'</t></is></c>';
            } else {
                $xml .= '<c r="'.$colLetter.'1" s="1"/>';
            }
        }
        $xml .= '</row>';

        // ردیف ۲: سرستون‌ها (B2:O2)
        $xml .= '<row r="2" ht="19.5" customHeight="1">';
        foreach ($headers as $colLetter => $label) {
            $xml .= '<c r="'.$colLetter.'2" s="2" t="inlineStr"><is><t>'.self::xmlEscape($label).'</t></is></c>';
        }
        $xml .= '</row>';

        // ردیف‌های داده (از ردیف ۳ به بعد)
        $rowNum = 3;
        $sumTariffRate = 0.0;
        $sumH = 0;
        $sumI = 0.0;
        $sumK = 0.0;
        $sumL = 0.0;
        $sumM = 0.0;

        foreach ($itemsData as $row) {
            $xml .= '<row r="'.$rowNum.'" ht="19.5" customHeight="1">';

            // B: ردیف
            $xml .= '<c r="B'.$rowNum.'" s="3"><v>'.((int) $row['index']).'</v></c>';

            // C: شماره واگن
            $wagonNo = (string) ($row['wagon_number'] ?? '');
            if (ctype_digit($wagonNo) && ! str_starts_with($wagonNo, '0')) {
                $xml .= '<c r="C'.$rowNum.'" s="3"><v>'.$wagonNo.'</v></c>';
            } else {
                $xml .= '<c r="C'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape($wagonNo).'</t></is></c>';
            }

            // D: شرح کالا
            $cargoDesc = (string) ($row['cargo_description'] ?? $row['tariff_name'] ?? '');
            $xml .= '<c r="D'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape($cargoDesc).'</t></is></c>';

            // E: عنوان تعرفه استفاده شده
            $usedTariffTitle = (string) ($row['used_tariff_title'] ?? $row['tariff_name'] ?? '');
            $xml .= '<c r="E'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape($usedTariffTitle).'</t></is></c>';

            $bookletRate = (float) ($row['booklet_rate'] ?? 0);
            $tariffRateVal = (float) ($row['tariff_rate'] ?? $bookletRate);

            // F: مبلغ تعرفه
            $xml .= '<c r="F'.$rowNum.'" s="4"><v>'.round($tariffRateVal).'</v></c>';

            // G: نام صاحب کالا
            $xml .= '<c r="G'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape((string) ($row['owner_name'] ?? '')).'</t></is></c>';

            $hVal = (int) round((float) ($row['total_with_vat'] ?? 0));
            $iVal = (float) ($row['customer_payable'] ?? 0);
            $tonnageVal = (float) ($row['operational_tonnage'] ?? 0);
            $perTon = (float) ($row['per_ton_rate'] ?? 0);
            $cap = (float) ($row['capacity'] ?? 65);
            $capStr = floor($cap) == $cap ? (string) ((int) $cap) : (string) $cap;
            $vatDivisor = (float) ($row['vat_divisor'] ?? 1.1);

            $sumTariffRate += $tariffRateVal;
            $sumH += $hVal;
            $sumI += $iVal;
            $sumK += $bookletRate;
            $sumL += $tonnageVal;
            $sumM += $perTon;

            // H: مبلغ با احتساب مالیات بر ارزش افزوده
            $xml .= '<c r="H'.$rowNum.'" s="4"><f>ROUND(I'.$rowNum.'*'.$vatDivisor.',0)</f><v>'.$hVal.'</v></c>';

            // I: مبلغ کل قابل دریافت از مشتری (L * M) برای تمام واگن‌ها
            $xml .= '<c r="I'.$rowNum.'" s="4"><f>L'.$rowNum.'*M'.$rowNum.'</f><v>'.$iVal.'</v></c>';

            // J: توضیحات/ شماره وسیله حمل
            $xml .= '<c r="J'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape((string) ($row['equipment_label'] ?? '')).'</t></is></c>';

            // K: مبلغ تعرفه در کتابچه (ستون سبز رنگ #92D050)
            $xml .= '<c r="K'.$rowNum.'" s="5"><v>'.round($bookletRate).'</v></c>';

            // L: تناژ (عملیاتی) برای تمام واگن‌ها
            $xml .= '<c r="L'.$rowNum.'" s="4"><v>'.$tonnageVal.'</v></c>';

            // M: محاسبه بر اساس کتابچه تعرفه (K / ظرفیت) برای تمام واگن‌ها
            $xml .= '<c r="M'.$rowNum.'" s="4"><f>K'.$rowNum.'/'.$capStr.'</f><v>'.$perTon.'</v></c>';

            // N: نحوه محاسبه
            $xml .= '<c r="N'.$rowNum.'" s="3" t="inlineStr"><is><t>'.self::xmlEscape((string) ($row['calc_method'] ?? 'طبق قرارداد')).'</t></is></c>';

            // O: توضیحات
            $notes = trim((string) ($row['notes'] ?? ''));
            if ($notes !== '') {
                $xml .= '<c r="O'.$rowNum.'" s="6" t="inlineStr"><is><t>'.self::xmlEscape($notes).'</t></is></c>';
            } else {
                $xml .= '<c r="O'.$rowNum.'" s="3"/>';
            }

            $xml .= '</row>';
            $rowNum++;
        }

        // ردیف جمع کل در انتهای جدول (در صورتی که حداقل یک ردیف داده وجود داشته باشد)
        if ($rowNum > 3) {
            $lastDataRow = $rowNum - 1;
            $xml .= '<row r="'.$rowNum.'" ht="22" customHeight="1">'
                .'<c r="B'.$rowNum.'" s="2" t="inlineStr"><is><t>جمع کل</t></is></c>'
                .'<c r="C'.$rowNum.'" s="2"/>'
                .'<c r="D'.$rowNum.'" s="2"/>'
                .'<c r="E'.$rowNum.'" s="2" t="inlineStr"><is><t>'.($lastDataRow - 2).' واگن</t></is></c>'
                .'<c r="F'.$rowNum.'" s="4"><f>SUM(F3:F'.$lastDataRow.')</f><v>'.round($sumTariffRate).'</v></c>'
                .'<c r="G'.$rowNum.'" s="2"/>'
                .'<c r="H'.$rowNum.'" s="4"><f>SUM(H3:H'.$lastDataRow.')</f><v>'.$sumH.'</v></c>'
                .'<c r="I'.$rowNum.'" s="4"><f>SUM(I3:I'.$lastDataRow.')</f><v>'.round($sumI).'</v></c>'
                .'<c r="J'.$rowNum.'" s="2"/>'
                .'<c r="K'.$rowNum.'" s="5"><f>SUM(K3:K'.$lastDataRow.')</f><v>'.round($sumK).'</v></c>'
                .'<c r="L'.$rowNum.'" s="4"><f>SUM(L3:L'.$lastDataRow.')</f><v>'.round($sumL, 2).'</v></c>'
                .'<c r="M'.$rowNum.'" s="4"><f>SUM(M3:M'.$lastDataRow.')</f><v>'.round($sumM).'</v></c>'
                .'<c r="N'.$rowNum.'" s="2"/>'
                .'<c r="O'.$rowNum.'" s="2"/>'
                .'</row>';
            $rowNum++;
        }

        // ردیف‌های امضا در پایین گزارش (دقیقاً مطابق ساختار فایل نمونه ستاد)
        $sigRow1 = $rowNum + 3;
        $sigRow2 = $rowNum + 6;
        $sigRow3 = $rowNum + 7;

        $xml .= '<row r="'.$sigRow1.'" ht="21" customHeight="1">'
            .'<c r="D'.$sigRow1.'" s="7" t="inlineStr"><is><t>امضاء طرف قرار داد / پیمانکار</t></is></c>'
            .'<c r="N'.$sigRow1.'" s="7" t="inlineStr"><is><t>امضاء مدیر شعبه</t></is></c>'
            .'</row>';

        $xml .= '<row r="'.$sigRow2.'" ht="21" customHeight="1">'
            .'<c r="D'.$sigRow2.'" s="7" t="inlineStr"><is><t>امضاء مدیر مجتمع </t></is></c>'
            .'</row>';

        $xml .= '<row r="'.$sigRow3.'" ht="21" customHeight="1">'
            .'<c r="N'.$sigRow3.'" s="7" t="inlineStr"><is><t>امضاء رئیس عملیات</t></is></c>'
            .'</row>';

        $xml .= '</sheetData>'
            .'<mergeCells count="1"><mergeCell ref="B1:O1"/></mergeCells>'
            .'</worksheet>';

        return $xml;
    }

    /**
     * @param  array<int, string>  $headers
     * @param  iterable<int, array<int, mixed>>  $rows
     * @param  array<int, mixed>|null  $totalsRow
     */
    public static function buildXlsx(
        string $sheetTitle,
        array $headers,
        iterable $rows,
        ?array $totalsRow = null
    ): string {
        $colCount = max(1, count($headers));
        $colWidths = array_fill(0, $colCount, 12);

        foreach ($headers as $idx => $header) {
            $len = self::utf8Len((string) $header);
            $colWidths[$idx] = max($colWidths[$idx], min(48, (int) ceil($len * 1.4) + 5));
        }

        $normalizedRows = [];
        foreach ($rows as $row) {
            $vals = array_values((array) $row);
            foreach ($vals as $idx => $val) {
                if ($idx < $colCount && $val !== null) {
                    $displayLen = is_numeric($val)
                        ? strlen(number_format((float) $val))
                        : self::utf8Len((string) $val);
                    $colWidths[$idx] = max($colWidths[$idx], min(55, (int) ceil($displayLen * 1.25) + 4));
                }
            }
            $normalizedRows[] = $vals;
        }

        if ($totalsRow !== null) {
            $totalsRow = array_values($totalsRow);
            foreach ($totalsRow as $idx => $val) {
                if ($idx < $colCount && $val !== null) {
                    $displayLen = is_numeric($val)
                        ? strlen(number_format((float) $val))
                        : self::utf8Len((string) $val);
                    $colWidths[$idx] = max($colWidths[$idx], min(55, (int) ceil($displayLen * 1.3) + 4));
                }
            }
        }

        $files = [
            '[Content_Types].xml' => self::contentTypesXml(),
            '_rels/.rels' => self::rootRelsXml(),
            'xl/_rels/workbook.xml.rels' => self::workbookRelsXml(),
            'xl/workbook.xml' => self::workbookXml($sheetTitle),
            'xl/styles.xml' => self::stylesXml(),
            'xl/worksheets/sheet1.xml' => self::sheetXml($sheetTitle, $headers, $normalizedRows, $totalsRow, $colWidths),
        ];

        return self::buildZipArchive($files);
    }

    private static function contentTypesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            .'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            .'<Default Extension="xml" ContentType="application/xml"/>'
            .'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            .'<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            .'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            .'</Types>';
    }

    private static function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            .'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            .'</Relationships>';
    }

    private static function workbookRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            .'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            .'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            .'</Relationships>';
    }

    private static function workbookXml(string $sheetTitle): string
    {
        // نام تب در اکسل حداکثر ۳۱ کاراکتر و بدون کاراکترهای غیرمجاز
        $tabName = preg_replace('/[\\\\\\/?*\\[\\]:]/u', ' ', trim($sheetTitle)) ?: 'گزارش';
        $tabName = self::utf8Substr($tabName, 0, 31);

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            .'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            .'<bookViews><workbookView rightToLeft="1"/></bookViews>'
            .'<sheets><sheet name="'.self::xmlEscape($tabName).'" sheetId="1" r:id="rId1"/></sheets>'
            .'</workbook>';
    }

    private static function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            .'<fonts count="3">'
            .'<font><sz val="11"/><color rgb="FF111827"/><name val="Tahoma"/><family val="2"/></font>'
            .'<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/><family val="2"/></font>'
            .'<font><b/><sz val="11"/><color rgb="FF1E293B"/><name val="Tahoma"/><family val="2"/></font>'
            .'</fonts>'
            .'<fills count="5">'
            .'<fill><patternFill patternType="none"/></fill>'
            .'<fill><patternFill patternType="gray125"/></fill>'
            .'<fill><patternFill patternType="solid"><fgColor rgb="FF1E3A8A"/><bgColor indexed="64"/></patternFill></fill>'
            .'<fill><patternFill patternType="solid"><fgColor rgb="FFFEF3C7"/><bgColor indexed="64"/></patternFill></fill>'
            .'<fill><patternFill patternType="solid"><fgColor rgb="FFEFF6FF"/><bgColor indexed="64"/></patternFill></fill>'
            .'</fills>'
            .'<borders count="2">'
            .'<border><left/><right/><top/><bottom/><diagonal/></border>'
            .'<border>'
            .'<left style="thin"><color rgb="FFCBD5E1"/></left>'
            .'<right style="thin"><color rgb="FFCBD5E1"/></right>'
            .'<top style="thin"><color rgb="FFCBD5E1"/></top>'
            .'<bottom style="thin"><color rgb="FFCBD5E1"/></bottom>'
            .'<diagonal/>'
            .'</border>'
            .'</borders>'
            .'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            .'<cellXfs count="8">'
            // 0: پیش‌فرض
            .'<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            // 1: سرستون جدول (آبی تیره، بولد سفید، وسط‌چین RTL)
            .'<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 2: سلول متنی عادی (راست‌چین RTL با کادر)
            .'<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="right" vertical="center" readingOrder="2" wrapText="1"/>'
            .'</xf>'
            // 3: سلول عدد صحیح / مبلغ (با جداکننده هزارگان #,##0)
            .'<xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 4: سلول عدد اعشاری (وزن 0.00)
            .'<xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 5: سلول متنی ردیف جمع کل (بولد با پس‌زمینه کهربایی)
            .'<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="right" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 6: سلول عددی ردیف جمع کل (بولد با پس‌زمینه کهربایی و جداکننده هزارگان)
            .'<xf numFmtId="3" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            // 7: بنر عنوان بالای گزارش
            .'<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            .'<alignment horizontal="center" vertical="center" readingOrder="2"/>'
            .'</xf>'
            .'</cellXfs>'
            .'</styleSheet>';
    }

    /**
     * @param  array<int, string>  $headers
     * @param  array<int, array<int, mixed>>  $rows
     * @param  array<int, mixed>|null  $totalsRow
     * @param  array<int, int>  $colWidths
     */
    private static function sheetXml(
        string $sheetTitle,
        array $headers,
        array $rows,
        ?array $totalsRow,
        array $colWidths
    ): string {
        $colCount = max(1, count($headers));
        $lastColLetter = self::colLetter($colCount - 1);

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            .'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            .'<sheetViews><sheetView rightToLeft="1" tabSelected="1" workbookViewId="0"/></sheetViews>'
            .'<sheetFormatPr defaultRowHeight="20"/>'
            .'<cols>';

        foreach ($colWidths as $idx => $width) {
            $colNum = $idx + 1;
            $xml .= '<col min="'.$colNum.'" max="'.$colNum.'" width="'.$width.'" customWidth="1"/>';
        }

        $xml .= '</cols><sheetData>';

        // ردیف ۱: عنوان گزارش
        $xml .= '<row r="1" ht="28" customHeight="1">';
        for ($c = 0; $c < $colCount; $c++) {
            $ref = self::colLetter($c).'1';
            if ($c === 0) {
                $xml .= '<c r="'.$ref.'" s="7" t="inlineStr"><is><t>'.self::xmlEscape($sheetTitle).'</t></is></c>';
            } else {
                $xml .= '<c r="'.$ref.'" s="7"/>';
            }
        }
        $xml .= '</row>';

        // ردیف ۲: سرستون‌ها
        $xml .= '<row r="2" ht="24" customHeight="1">';
        foreach ($headers as $c => $headerText) {
            $ref = self::colLetter($c).'2';
            $xml .= '<c r="'.$ref.'" s="1" t="inlineStr"><is><t>'.self::xmlEscape((string) $headerText).'</t></is></c>';
        }
        $xml .= '</row>';

        // ردیف‌های داده
        $rowNum = 3;
        foreach ($rows as $row) {
            $xml .= '<row r="'.$rowNum.'" ht="21" customHeight="1">';
            for ($c = 0; $c < $colCount; $c++) {
                $val = $row[$c] ?? '';
                $ref = self::colLetter($c).$rowNum;
                $xml .= self::buildCellXml($ref, $val, false);
            }
            $xml .= '</row>';
            $rowNum++;
        }

        // ردیف جمع کل (در صورت وجود)
        if ($totalsRow !== null) {
            $xml .= '<row r="'.$rowNum.'" ht="24" customHeight="1">';
            for ($c = 0; $c < $colCount; $c++) {
                $val = $totalsRow[$c] ?? '';
                $ref = self::colLetter($c).$rowNum;
                $xml .= self::buildCellXml($ref, $val, true);
            }
            $xml .= '</row>';
        }

        $xml .= '</sheetData>';

        if ($colCount > 1) {
            $xml .= '<mergeCells count="1"><mergeCell ref="A1:'.$lastColLetter.'1"/></mergeCells>';
        }

        $xml .= '</worksheet>';

        return $xml;
    }

    private static function buildCellXml(string $ref, mixed $val, bool $isTotalRow): string
    {
        if (is_int($val) || is_float($val)) {
            $isFloat = is_float($val) && floor($val) != $val;
            $style = $isTotalRow ? 6 : ($isFloat ? 4 : 3);

            return '<c r="'.$ref.'" s="'.$style.'"><v>'.$val.'</v></c>';
        }

        $str = trim((string) ($val ?? ''));

        return '<c r="'.$ref.'" s="'.($isTotalRow ? 5 : 2).'" t="inlineStr"><is><t>'.self::xmlEscape($str).'</t></is></c>';
    }

    /**
     * تبدیل اندیس ستون (۰، ۱، ۲، ...) به حروف ستون اکسل (A, B, C, ..., Z, AA, AB, ...)
     */
    private static function colLetter(int $index): string
    {
        $letter = '';
        while ($index >= 0) {
            $letter = chr(($index % 26) + 65).$letter;
            $index = intdiv($index, 26) - 1;
        }

        return $letter;
    }

    private static function xmlEscape(string $value): string
    {
        // حذف کاراکترهای کنترلی غیرمجاز در XML 1.0
        $clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value) ?? '';

        return htmlspecialchars($clean, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private static function utf8Len(string $value): int
    {
        if (function_exists('mb_strlen')) {
            return (int) mb_strlen($value, 'UTF-8');
        }

        $count = preg_match_all('/./us', $value);

        return $count !== false ? $count : strlen($value);
    }

    private static function utf8Substr(string $value, int $start, int $length): string
    {
        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, $start, $length, 'UTF-8');
        }

        $chars = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY);
        if (! is_array($chars)) {
            return substr($value, $start, $length);
        }

        return implode('', array_slice($chars, $start, $length));
    }

    /**
     * ساخت آرشیو ZIP استاندارد در حافظه بدون نیاز به افزونه ext-zip یا فایل موقت دیسک.
     *
     * @param  array<string, string>  $entries
     */
    private static function buildZipArchive(array $entries): string
    {
        $localParts = [];
        $centralParts = [];
        $offset = 0;
        $count = 0;

        foreach ($entries as $name => $data) {
            $name = str_replace('\\', '/', $name);
            $uncompressedSize = strlen($data);
            $crc = crc32($data);

            $compressed = function_exists('gzdeflate') ? gzdeflate($data, 6) : false;
            if ($compressed !== false && strlen($compressed) < $uncompressedSize) {
                $method = 8; // Deflate
                $payload = $compressed;
            } else {
                $method = 0; // Store
                $payload = $data;
            }

            $compressedSize = strlen($payload);
            $nameLen = strlen($name);

            // DOS timestamp (2026-01-01 12:00:00)
            $dosTime = (12 << 11) | (0 << 5) | 0;
            $dosDate = ((2026 - 1980) << 9) | (1 << 5) | 1;

            $localHeader = pack(
                'VvvvvvVVVvv',
                0x04034B50,
                20,
                0,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                $nameLen,
                0
            ).$name;

            $localEntry = $localHeader.$payload;
            $localParts[] = $localEntry;

            $centralParts[] = pack(
                'VvvvvvvVVVvvvvvVV',
                0x02014B50,
                20,
                20,
                0,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                $nameLen,
                0,
                0,
                0,
                0,
                32,
                $offset
            ).$name;

            $offset += strlen($localEntry);
            $count++;
        }

        $centralDir = implode('', $centralParts);
        $localData = implode('', $localParts);

        $eocd = pack(
            'VvvvvVVv',
            0x06054B50,
            0,
            0,
            $count,
            $count,
            strlen($centralDir),
            strlen($localData),
            0
        );

        return $localData.$centralDir.$eocd;
    }
}
